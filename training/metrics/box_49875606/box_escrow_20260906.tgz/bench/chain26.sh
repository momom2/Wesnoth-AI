#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE27 ]; do sleep 120; done
tar xzf /workspace/bench/stage_serve.tar.gz -C /workspace/Wesnoth-AI
export TORCHINDUCTOR_COMPILE_THREADS=1
run() { name=$1; shift; timeout 2400 python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 16 --games 32 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --packed-trunk --packed-embed --serve-threads 2 --dollars-per-hour 0.33 --out /workspace/bench/$name.json "$@" > /workspace/bench/$name.log 2>&1; }
run pool_serve2 --serve-processes 2
touch /workspace/bench/DONE28

#!/bin/bash
cd /workspace/Wesnoth-AI
export PATH=/root/.cargo/bin:$PATH
while [ ! -f /workspace/bench/DONE15b ]; do sleep 30; done
sleep 180
tar xzf /workspace/bench/stage_head.tar.gz -C /workspace/Wesnoth-AI
OMP_NUM_THREADS=2 python -m pytest tests/test_server_priors_cuda.py tests/test_server_priors_staging.py tests/test_server_priors.py -q > /workspace/bench/staged_priors_tests.log 2>&1
while [ ! -f /workspace/bench/DONE16 ]; do sleep 60; done
python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 16 --games 16 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/pool_staged16.json > /workspace/bench/pool_staged16.log 2>&1
touch /workspace/bench/DONE17

#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE22 ]; do sleep 60; done
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1
s=$SECONDS
python tools/run_elo_batch.py --label-a relset --spec-a training/checkpoints/seed.pt --relevant-set-a --label-b full --spec-b training/checkpoints/seed.pt --outdir /workspace/bench/probe_relset --games 40 --mcts-sims 0 --raw-temperature-a 0 --raw-temperature-b 0 --device cuda --jobs 10 --max-extra-games 0 --time-budget-min 40 --persistent-workers --seed-base 40000 > /workspace/bench/probe_relset.log 2>&1
echo $((SECONDS-s)) > /workspace/bench/probe_relset.time
touch /workspace/bench/DONE23

#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE12 ]; do sleep 30; done
tar xzf /workspace/bench/stage_best.tar.gz -C /workspace/Wesnoth-AI
(cd rust/wesnoth_core && maturin build --release -o /workspace/wheels > /workspace/bench/wheel_build.log 2>&1 && pip install --force-reinstall --no-deps /workspace/wheels/*.whl >> /workspace/bench/wheel_build.log 2>&1)
python -c "import tools.pathfind_sim as pf; print(\"rust:\", pf._RUST is not None)" > /workspace/bench/rust_check.txt 2>&1
python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 19 --games 16 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/pool_best19.json > /workspace/bench/pool_best19.log 2>&1
sp=$(pgrep -f "multiprocessing.spawn" | head -1); echo "actor threads after cap: $(ls /proc/$sp/task 2>/dev/null | wc -l)" > /workspace/bench/actor_threads.txt
touch /workspace/bench/DONE13

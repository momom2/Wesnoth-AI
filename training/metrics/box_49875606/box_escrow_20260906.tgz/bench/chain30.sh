#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE31 ]; do sleep 120; done
cp /workspace/bench/turn_gap.py tools/turn_gap.py; cp /workspace/bench/raw_player.py tools/raw_player.py
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
timeout 14400 python tools/turn_gap.py --checkpoint training/checkpoints/seed.pt --device cuda --jobs 12 --cap-turns 30 --playout-temperature 0.5 --n-states 60 --alternatives 0 --continue-edits 3 --playouts 40 --seed 3 --dollars-per-hour 0.33 --states-json configs/bench_states.json --dataset /workspace/bench_dataset --out /workspace/bench/turn_gap/continue1.json > /workspace/bench/turn_gap/continue1.log 2>&1
touch /workspace/bench/DONE32

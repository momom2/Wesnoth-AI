#!/bin/bash
cd /workspace/Wesnoth-AI
export PATH=/root/.cargo/bin:$PATH
while [ ! -f /workspace/bench/DONE15 ]; do sleep 30; done
(cd rust/wesnoth_core && maturin build --release -o /workspace/wheels > /workspace/bench/wheel_build.log 2>&1 && pip install --force-reinstall --no-deps /workspace/wheels/*.whl >> /workspace/bench/wheel_build.log 2>&1); python -c "from wesnoth_ai.encoder import _rust_encode_kernel; print("rust encode kernel:", _rust_encode_kernel() is not None)" > /workspace/bench/rust_check.txt 2>&1
python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 16 --games 16 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/pool_best16.json > /workspace/bench/pool_best16.log 2>&1
sp=$(pgrep -f "multiprocessing.spawn" | head -1); echo "actor threads after cap: $(ls /proc/$sp/task 2>/dev/null | wc -l)" > /workspace/bench/actor_threads.txt
touch /workspace/bench/DONE15b
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
mv /workspace/bench/turn_gap/run1.log /workspace/bench/turn_gap/run1_noflag.log 2>/dev/null
python tools/turn_gap.py --checkpoint training/checkpoints/seed.pt --device cuda --jobs 14 --cap-turns 30 --playout-temperature 0.5 --dollars-per-hour 0.33 --states-json configs/bench_states.json --dataset /workspace/bench_dataset --out /workspace/bench/turn_gap/run1.json > /workspace/bench/turn_gap/run1.log 2>&1
touch /workspace/bench/DONE16

| quantity | value |
|---|---|
| positions | 12 |
| gap >= 0.25 | 3/12 = 0.250 +- 0.125 |
| same, permutation null (200 shuffles) | 0.130 |
| mean gap | +0.102 +- 0.049 |
| mean split-half gap | +0.087 +- 0.084 (n=12) |
| split-half gap >= 0.25 | 0.250 |
| base turn best or tied | 5/12 = 0.417 |
| positions without a distinct alternative | 0 |
| positions whose base turn ended the game | 0 |
| distinct alternatives per position | 2.75 of 0 |
| playouts played | 1800, capped 134 (0.074) |
| decisions per turn, base / alternatives | 9.7 / 10.4 |
| wall | 0.64 h, $0.21 |

| gap bin | positions |
|---|---|
| [-0.25, +0.00) | 4 |
| [+0.00, +0.25) | 5 |
| [+0.25, +0.50) | 3 |

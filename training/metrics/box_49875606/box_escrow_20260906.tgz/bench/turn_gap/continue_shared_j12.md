| quantity | value |
|---|---|
| positions | 12 |
| gap >= 0.25 | 1/12 = 0.083 +- 0.080 |
| same, permutation null (200 shuffles) | 0.124 |
| mean gap | +0.063 +- 0.046 |
| mean split-half gap | -0.079 +- 0.062 (n=12) |
| split-half gap >= 0.25 | 0.167 |
| base turn best or tied | 6/12 = 0.500 |
| positions without a distinct alternative | 0 |
| positions whose base turn ended the game | 0 |
| distinct alternatives per position | 2.92 of 0 |
| playouts played | 1880, capped 155 (0.082) |
| decisions per turn, base / alternatives | 9.4 / 10.9 |
| wall | 0.65 h, $0.22 |

| gap bin | positions |
|---|---|
| [-0.25, +0.00) | 5 |
| [+0.00, +0.25) | 6 |
| [+0.25, +0.50) | 1 |

#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE25 ]; do sleep 60; done
tar xzf /workspace/bench/stage_head4.tar.gz -C /workspace/Wesnoth-AI
run() { name=$1; shift; python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 16 --games 32 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --packed-trunk --serve-threads 2 --dollars-per-hour 0.33 --out /workspace/bench/$name.json "$@" > /workspace/bench/$name.log 2>&1; }
run pool_c_control
run pool_c_packed_embed --packed-embed
run pool_c_coalesce --coalesce length
run pool_c_coalesce_embed --coalesce length --packed-embed
touch /workspace/bench/DONE26

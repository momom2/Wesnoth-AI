#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE26 ]; do sleep 60; done
tar xzf /workspace/bench/stage_train.tar.gz -C /workspace/Wesnoth-AI
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=4
timeout 1500 python tools/bench_train_step.py --checkpoint training/checkpoints/seed.pt --device cuda --dataset /workspace/bench_dataset --batch-sizes 1,16 --precisions fp32 --n-list 1024 --parity-n 64 --repeats 2 --out /workspace/bench/train_step_batched.json --md /workspace/bench/train_step_batched.md > /workspace/bench/train_step_batched.log 2>&1
touch /workspace/bench/DONE26b
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
WORKERS=14 JOBS=10 bash /workspace/bench/relset_arms_box.sh > /workspace/bench/relset_arms.log 2>&1
touch /workspace/bench/DONE27

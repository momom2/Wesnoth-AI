#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE8 ]; do sleep 20; done
run() { name=$1; shift; python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/$name.json "$@" > /workspace/bench/$name.log 2>&1; }
run pool_a28 --actors 28 --games 28
run pool_a38 --actors 38 --games 38
touch /workspace/bench/DONE9

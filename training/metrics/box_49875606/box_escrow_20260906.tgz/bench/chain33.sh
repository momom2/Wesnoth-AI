#!/bin/bash
# Learning-rate control for the imitation fine-tune recipe (2026-09-05
# night): the control arm (seed + 0.5 epoch at lr 1e-4) loses ~135 Elo
# to the seed at argmax with an equal holdout CE. Same recipe, same
# stream and seed, lr 1e-5; then 800 games vs the seed. Distinguishes
# drift at a 20x higher lr than the seed's last epoch from the recipe
# itself (winners-only, per-game weight, action-type weights).
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE34 ]; do sleep 120; done
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
OUT=/workspace/relset/control_lr1e-5
mkdir -p $OUT
python tools/supervised_train.py replays_dataset_imitation --checkpoint $OUT/arm.pt --init-from training/checkpoints/seed.pt --imitation-config configs/imitation.json --d-model 384 --num-layers 8 --num-heads 12 --d-ff 1536 --epochs 1 --max-pairs 1260000 --seed 20260905 --bs 64 --lr 1e-5 --device cuda --workers 14 --eval-every 50000 --eval-pairs 1200 --eval-pairs-per-game 8 --eval-sample-seed 0 --ckpt-every 2000 --log-every 100 > $OUT/train.log 2>&1
touch /workspace/bench/DONE35a
python tools/run_elo_batch.py --label-a control_lr1e5 --spec-a $OUT/arm.pt --label-b seed_t0 --spec-b training/checkpoints/seed.pt --outdir /workspace/relset/control_lr1e-5_vs_seed --games 800 --seed-base 30000 --mcts-sims 0 --raw-temperature-a 0 --raw-temperature-b 0 --persistent-workers --no-infer-compile --device cuda --jobs 10 --time-budget-min 120 > /workspace/relset/control_lr1e-5_vs_seed.log 2>&1
touch /workspace/bench/DONE35

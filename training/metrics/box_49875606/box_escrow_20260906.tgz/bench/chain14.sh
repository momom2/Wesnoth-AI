#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE17 ]; do sleep 60; done
cp /workspace/bench/bench_pool_threads.py tools/bench_pool.py
python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 16 --games 32 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --serve-threads 4 --dollars-per-hour 0.33 --out /workspace/bench/pool_threads4.json > /workspace/bench/pool_threads4.log 2>&1
python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 16 --games 32 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --serve-threads 2 --dollars-per-hour 0.33 --out /workspace/bench/pool_threads2_g32.json > /workspace/bench/pool_threads2_g32.log 2>&1
touch /workspace/bench/DONE18

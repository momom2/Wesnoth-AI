#!/bin/bash
cd /workspace/Wesnoth-AI
run() { name=$1; shift; python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --games 16 --sims 32 --leaf-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/$name.json "$@" > /workspace/bench/$name.log 2>&1; }
run pool_mb64 --actors 19 --max-batch 64
run pool_mb64_a14 --actors 14 --max-batch 64
touch /workspace/bench/DONE4

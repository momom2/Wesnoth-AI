#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE5 ]; do sleep 20; done
python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 19 --games 16 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/pool_prof.json > /workspace/bench/pool_prof.log 2>&1 &
PID=$!
sleep 150
py-spy record --pid $PID --duration 60 --format raw --threads --nonblocking -o /workspace/bench/prof_all.txt > /workspace/bench/prof_all.err 2>&1
py-spy record --pid $PID --duration 60 --format raw --threads --gil -o /workspace/bench/prof_gil.txt > /workspace/bench/prof_gil.err 2>&1
py-spy dump --pid $PID > /workspace/bench/prof_dump.txt 2>&1
nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv,noheader > /workspace/bench/prof_gpu.txt
top -b -n 1 | head -25 > /workspace/bench/prof_top.txt
wait $PID
touch /workspace/bench/DONE6

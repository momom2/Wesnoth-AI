#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE10 ]; do sleep 20; done
run() { name=$1; tb=$2; s=$SECONDS; python tools/run_elo_batch.py --label-a t$tb --spec-a training/checkpoints/seed.pt --label-b t0 --spec-b training/checkpoints/seed.pt --outdir /workspace/bench/sweep_$name --games 40 --mcts-sims 0 --raw-temperature-a $tb --raw-temperature-b 0 --device cuda --jobs 10 --max-extra-games 0 --time-budget-min 40 --persistent-workers --seed-base 20000 > /workspace/bench/sweep_$name.log 2>&1; echo $((SECONDS-s)) > /workspace/bench/sweep_$name.time; }
run t0 0
run t025 0.25
run t05 0.5
run t1 1
touch /workspace/bench/DONE11

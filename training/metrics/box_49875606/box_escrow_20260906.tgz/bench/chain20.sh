#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE23 ]; do sleep 60; done
export TORCHINDUCTOR_COMPILE_THREADS=4 OMP_NUM_THREADS=4
python tools/bench_train_step.py --checkpoint training/checkpoints/seed.pt --device cuda --source bench --dataset /workspace/bench_dataset --compile --out /workspace/bench/train_step.json --md /workspace/bench/train_step.md > /workspace/bench/train_step.log 2>&1
touch /workspace/bench/DONE24

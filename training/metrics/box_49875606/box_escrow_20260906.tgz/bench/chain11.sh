#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE15 ]; do sleep 30; done
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
mv /workspace/bench/turn_gap/run1.log /workspace/bench/turn_gap/run1_noflag.log 2>/dev/null
python tools/turn_gap.py --checkpoint training/checkpoints/seed.pt --device cuda --jobs 14 --cap-turns 30 --playout-temperature 0.5 --dollars-per-hour 0.33 --states-json configs/bench_states.json --dataset /workspace/bench_dataset --out /workspace/bench/turn_gap/run1.json > /workspace/bench/turn_gap/run1.log 2>&1
touch /workspace/bench/DONE16

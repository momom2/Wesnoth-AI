#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE14 ]; do sleep 30; done
python tools/bench_model_cost.py --checkpoint training/checkpoints/seed.pt --states-json configs/bench_states.json --dataset /workspace/bench_dataset --device cuda --hex-tokens 300 600 900 --out /workspace/bench/model_cost.json > /workspace/bench/model_cost.log 2>&1
touch /workspace/bench/DONE15

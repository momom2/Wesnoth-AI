# Training-path cost (tools/bench_train_step.py)

seed.pt (15.03 M params) on NVIDIA GeForce RTX 4090, torch 2.5.1+cu124; source: {'kind': 'pool', 'actors': 8, 'games': 8, 'decisive': 0, 'sims': 32, 'max_turns': 12, 'gen_seconds': 102.07858803495765, 'forwards': 62655, 'leaves_per_s': 613.7917971449926, 'experiences_per_game': 245.5, 'experiences': 1964, 'build_seconds': 102.79180126823485}

## Stage costs, ms per experience (median of 2 steps; 1964 unique experiences, cycled)

| precision | B | N | compiled | encode_raw | encode | forward | policy_loss | value_loss | backward | fwd+bwd | clip ms | optimizer ms | snapshot ms | step wall ms/exp | unattributed ms/exp | GPU peak MB | warmup s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| fp32 | 16 | 1024 | no | 0.29 | 0.31 | 1.94 | 0.01 | 0.00 | 5.15 | 7.69 | 1.43 | 2.74 | 4.31 | 7.79 | 0.08 | 3489 | 8.0 |
| bf16 | 16 | 1024 | no | 0.29 | 0.48 | 0.75 | 0.12 | 0.01 | 1.89 | 3.54 | 1.60 | 2.72 | 5.15 | 3.66 | 0.10 | 2228 | 3.7 |

## Parity on one batch of 64 (optimizer stubbed, no clipping; reference fp32 B=1 -- for the compiled rows the eager fp32 B=1 on the same weights; pass = loss within 1%, gradient norm within 5%, cosine >= 0.99)

| config | total loss | loss rel diff | grad norm | norm ratio | grad rel L2 diff | cosine | ok |
|---|---|---|---|---|---|---|---|
| fp32 B=1 | 3.90767 | 0.00e+00 | 4.7633 | 1.0000 | 0.00e+00 | 1.00000 | ref |
| fp32 B=1 rerun | 3.90767 | 0.00e+00 | 4.7633 | 1.0000 | 0.00e+00 | 1.00000 | yes |
| fp32 B=16 | 3.90767 | 6.43e-08 | 4.7633 | 1.0000 | 3.41e-06 | 1.00000 | yes |
| bf16 B=16 | 3.91179 | 1.05e-03 | 4.7733 | 1.0021 | 3.32e-02 | 0.99945 | yes |

## Implied az_loop iteration (24 games, holdout 0.2, 540 experiences per game, step cap 4000, 1 trial(s), 32 sims)

| precision | B | compiled | train-path s | generation s at 833 leaves/s | fraction | generation s at 489 leaves/s | fraction |
|---|---|---|---|---|---|---|---|
| fp32 | 16 | no | 78.0 | 498 | 0.135 | 848 | 0.084 |
| bf16 | 16 | no | 36.2 | 498 | 0.068 | 848 | 0.041 |

Training-path passes per iteration: 9912 forward+backward experiences (step 4000, held-out 2700 x 2, signal 512) and 648 forward-only.

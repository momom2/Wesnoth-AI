#!/bin/bash
# turn_gap through the shared inference server: the continue-edit run's
# first 12 positions (same config as chain30, seed 3) with 12 and then
# 24 workers; per-position `secs` compare with chain30's records of
# the same positions (per-process, one model per worker).
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE33 ]; do sleep 120; done
tar xzf /workspace/bench/stage_head6.tar.gz -C /workspace/Wesnoth-AI
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
COMMON="--checkpoint training/checkpoints/seed.pt --device cuda --cap-turns 30 --playout-temperature 0.5 --positions 0,1,2,3,4,5,6,7,8,9,10,11 --alternatives 0 --continue-edits 3 --playouts 40 --seed 3 --dollars-per-hour 0.33 --states-json configs/bench_states.json --dataset /workspace/bench_dataset --shared-inference"
for J in 12 24; do
  timeout 5400 python tools/turn_gap.py $COMMON --jobs $J --out /workspace/bench/turn_gap/continue_shared_j$J.json > /workspace/bench/turn_gap/continue_shared_j$J.log 2>&1
done
touch /workspace/bench/DONE34

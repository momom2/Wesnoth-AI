#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE18 ]; do sleep 60; done
tar xzf /workspace/bench/stage_head2.tar.gz -C /workspace/Wesnoth-AI
OMP_NUM_THREADS=2 python -m pytest tests/test_packed_trunk_cuda.py tests/test_packed_trunk.py -q -rs -s > /workspace/bench/packed_trunk_tests.log 2>&1
python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 16 --games 32 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --serve-threads 2 --packed-trunk --dollars-per-hour 0.33 --out /workspace/bench/pool_packedtrunk.json > /workspace/bench/pool_packedtrunk.log 2>&1
touch /workspace/bench/DONE19

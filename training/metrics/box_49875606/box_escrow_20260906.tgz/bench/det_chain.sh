#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE4 ]; do sleep 20; done
run() { name=$1; shift; s=$SECONDS; python tools/run_elo_batch.py --label-a t0a --spec-a training/checkpoints/seed.pt --label-b t0b --spec-b training/checkpoints/seed.pt --outdir /workspace/bench/det_$name --mcts-sims 0 --raw-temperature-a 0 --raw-temperature-b 0 --device cuda --jobs 6 --max-extra-games 0 --time-budget-min 30 "$@" > /workspace/bench/det_$name.log 2>&1; echo $((SECONDS-s)) > /workspace/bench/det_$name.time; }
run w1a --seed-base 10012 --games 2 --persistent-workers
run w1b --seed-base 10016 --games 4 --persistent-workers
run w2a --seed-base 10012 --games 2 --persistent-workers
run w2b --seed-base 10016 --games 4 --persistent-workers
run p1a --seed-base 10012 --games 2
run p1b --seed-base 10016 --games 4
touch /workspace/bench/DONE5

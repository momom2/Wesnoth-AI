#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE11 ]; do sleep 20; done
cp /workspace/bench/bench_pool_capped.py tools/bench_pool.py
# 1. Whole-pool profile: server AND actor processes (py-spy as parent, subprocesses sampled).
py-spy record --duration 1500 --rate 50 --format raw --threads --idle --subprocesses --nonblocking -o /workspace/bench/prof_pool_all.txt -- python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 19 --games 16 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/pool_prof_all.json > /workspace/bench/pool_prof_all.log 2>&1
touch /workspace/bench/DONE12a
# 2. Catalog edges at raw:t0 (seed vs four catalog checkpoints), persistent workers.
while [ ! -f /workspace/bench/CKPTS_READY ]; do sleep 20; done
edge() { name=$1; file=$2; s=$SECONDS; python tools/run_elo_batch.py --label-a seed_l4_0k --spec-a training/checkpoints/seed.pt --label-b $name --spec-b training/checkpoints/$file --outdir /workspace/bench/cat_$name --games 40 --mcts-sims 0 --raw-temperature-a 0 --raw-temperature-b 0 --device cuda --jobs 10 --max-extra-games 0 --time-budget-min 60 --persistent-workers --seed-base 30000 > /workspace/bench/cat_$name.log 2>&1; echo $((SECONDS-s)) > /workspace/bench/cat_$name.time; }
edge 2291k selfplay_seed_20260718.pt
edge 2516k campaign_live_20260730.pt
edge l4_495k 2516k-b-294k-l4-495k.pt
edge tcs2_558k eval_tcs2_3367830.pt
touch /workspace/bench/DONE12b
# 3. Turn-level value gap (phase-2 prerequisite), pre-registered settings.
while [ ! -f /workspace/bench/DATASET_READY ]; do sleep 20; done
mkdir -p /workspace/bench/turn_gap
python tools/turn_gap.py --checkpoint training/checkpoints/seed.pt --device cuda --jobs 14 --cap-turns 30 --dollars-per-hour 0.33 --states-json configs/bench_states.json --dataset /workspace/bench_dataset --out /workspace/bench/turn_gap/run1.json > /workspace/bench/turn_gap/run1.log 2>&1
touch /workspace/bench/DONE12

#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE30 ]; do sleep 120; done
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
mkdir -p /workspace/toprated
python tools/player_ratings.py fit --dataset replays_dataset_imitation --min-games 30 --quantile 0.75 --out /workspace/toprated/ratings --report --build-dataset replays_dataset_toprated > /workspace/toprated/fit.log 2>&1
ARCH="--d-model 384 --num-layers 8 --num-heads 12 --d-ff 1536"
EVAL="--eval-every 50000 --eval-pairs 1200 --eval-pairs-per-game 8 --eval-sample-seed 0"
python tools/supervised_train.py replays_dataset_toprated --checkpoint /workspace/toprated/arm.pt --init-from training/checkpoints/seed.pt --imitation-config configs/imitation.json $ARCH --epochs 30 --max-pairs 1260000 --seed 20260905 --bs 64 --lr 1e-4 --device cuda --workers 14 $EVAL --ckpt-every 2000 --log-every 100 > /workspace/toprated/train.log 2>&1
touch /workspace/bench/DONE31a
CONTROL=/workspace/relset/control/arm.pt
python tools/supervised_train.py replays_dataset_toprated --eval-only --resume $CONTROL --imitation-config configs/imitation.json $ARCH --device cuda $EVAL --eval-json /workspace/toprated/control_on_toprated_holdout.json > /workspace/toprated/barrier.log 2>&1
MATCH="--mcts-sims 0 --raw-temperature-a 0 --raw-temperature-b 0 --persistent-workers --no-infer-compile --device cuda --jobs 10"
python tools/run_elo_batch.py --label-a toprated --spec-a /workspace/toprated/arm.pt --label-b seed_t0 --spec-b training/checkpoints/seed.pt --outdir /workspace/toprated/vs_seed --games 1300 --seed-base 40000 $MATCH --time-budget-min 120 > /workspace/toprated/vs_seed.log 2>&1
python tools/run_elo_batch.py --label-a toprated --spec-a /workspace/toprated/arm.pt --label-b control --spec-b $CONTROL --outdir /workspace/toprated/vs_control --games 600 --seed-base 50000 $MATCH --time-budget-min 60 > /workspace/toprated/vs_control.log 2>&1
touch /workspace/bench/DONE31

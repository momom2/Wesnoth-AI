#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE28 ]; do sleep 120; done
tar xzf /workspace/bench/stage_head5.tar.gz -C /workspace/Wesnoth-AI
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=4
timeout 2400 python tools/bench_train_step.py --checkpoint training/checkpoints/seed.pt --device cuda --source pool --experiences-out /workspace/bench/train_step_pool_exps.pkl --batch-sizes 16 --precisions fp32,bf16 --n-list 1024 --parity-n 64 --repeats 2 --out /workspace/bench/train_step_shipped.json --md /workspace/bench/train_step_shipped.md > /workspace/bench/train_step_shipped.log 2>&1
touch /workspace/bench/DONE29

#!/bin/bash
# Eval throughput vs worker count through the shared inference server
# (the server is launch-bound at ~12 ms per batch whatever its size:
# more workers per server should amortize it). Rows: jobs 10/20/30/40,
# 4 games per worker; a 40-s py-spy of one worker during the 20-jobs row.
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE32 ]; do sleep 120; done
tar xzf /workspace/bench/stage_head5.tar.gz -C /workspace/Wesnoth-AI
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
OUT=/workspace/bench/eval_jobs
mkdir -p $OUT
MATCH="--mcts-sims 0 --raw-temperature-a 0 --raw-temperature-b 0 --device cuda --persistent-workers --shared-inference --max-extra-games 0 --seed-base 20000 --time-budget-min 30"
for J in 10 20 30 40; do
  G=$((J * 4))
  t0=$(date +%s)
  if [ "$J" = 20 ]; then
    ( sleep 45; pid=$(pgrep -f "elo_eval_game.py --worker" | head -1); [ -n "$pid" ] && py-spy record --pid $pid -d 40 --rate 100 --format raw -o $OUT/worker_j20.txt > $OUT/pyspy_j20.log 2>&1 ) &
  fi
  timeout 1800 python tools/run_elo_batch.py --label-a seed --spec-a training/checkpoints/seed.pt --label-b seed_ref --spec-b training/checkpoints/seed.pt --games $G --jobs $J --outdir $OUT/j$J $MATCH > $OUT/j$J.log 2>&1
  echo "$J $G $(( $(date +%s) - t0 ))" >> $OUT/rows.txt
done
touch /workspace/bench/DONE33

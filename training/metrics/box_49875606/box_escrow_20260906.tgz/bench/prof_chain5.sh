#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE9 ]; do sleep 20; done
cp /workspace/bench/actor_pool_packed.py tools/actor_pool.py
run() { name=$1; shift; python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/$name.json "$@" > /workspace/bench/$name.log 2>&1; }
run pool_packed19 --actors 19 --games 16
run pool_packed28 --actors 28 --games 28
touch /workspace/bench/DONE10

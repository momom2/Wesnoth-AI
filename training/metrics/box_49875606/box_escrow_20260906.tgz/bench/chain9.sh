#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE13 ]; do sleep 30; done
py-spy record --duration 1500 --rate 50 --format raw --threads --idle --subprocesses --nonblocking -o /workspace/bench/prof_pool_all.txt -- python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 16 --games 16 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/pool_prof_all.json > /workspace/bench/pool_prof_all.log 2>&1
touch /workspace/bench/DONE14

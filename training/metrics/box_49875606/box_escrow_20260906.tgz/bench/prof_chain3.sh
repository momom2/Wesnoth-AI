#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE7 ]; do sleep 20; done
python -c "import torch; print(\"default torch threads:\", torch.get_num_threads())" > /workspace/bench/torch_threads.txt 2>&1
OMP_NUM_THREADS=4 python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 19 --games 16 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33 --out /workspace/bench/pool_omp4.json > /workspace/bench/pool_omp4.log 2>&1
touch /workspace/bench/DONE8

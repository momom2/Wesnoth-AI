#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE24 ]; do sleep 60; done
tar xzf /workspace/bench/stage_eval.tar.gz -C /workspace/Wesnoth-AI
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1
s=$SECONDS
python tools/run_elo_batch.py --label-a seed --spec-a training/checkpoints/seed.pt --label-b seed_ref --spec-b training/checkpoints/seed.pt --games 40 --max-extra-games 0 --seed-base 20000 --outdir /workspace/bench/shared_inf_40 --mcts-sims 0 --raw-temperature-a 0 --raw-temperature-b 0 --device cuda --jobs 10 --persistent-workers --shared-inference --time-budget-min 30 > /workspace/bench/shared_inf_40.log 2>&1
echo $((SECONDS-s)) > /workspace/bench/shared_inf_40.time
touch /workspace/bench/DONE25

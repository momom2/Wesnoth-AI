#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE21 ]; do sleep 60; done
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python tools/turn_gap.py --checkpoint training/checkpoints/seed.pt --device cuda --jobs 12 --cap-turns 30 --playout-temperature 0.5 --positions 2,3,4,9,14,18,20,29,42,49,57,59 --playouts 160 --playout-offset 40 --dollars-per-hour 0.33 --states-json configs/bench_states.json --dataset /workspace/bench_dataset --out /workspace/bench/turn_gap/confirm1.json > /workspace/bench/turn_gap/confirm1.log 2>&1
touch /workspace/bench/DONE22

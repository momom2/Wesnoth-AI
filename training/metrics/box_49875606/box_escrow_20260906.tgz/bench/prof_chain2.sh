#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE6 ]; do sleep 20; done
POOL="python tools/bench_pool.py --checkpoint training/checkpoints/seed.pt --actors 19 --games 16 --sims 32 --leaf-batch 16 --max-batch 16 --server-priors --infer-bf16 --dollars-per-hour 0.33"
py-spy record --duration 1500 --rate 100 --format raw --threads --idle --nonblocking -o /workspace/bench/prof_idle.txt -- $POOL --out /workspace/bench/pool_prof_idle.json > /workspace/bench/pool_prof_idle.log 2>&1
py-spy record --duration 1500 --rate 100 --format raw --threads --gil --nonblocking -o /workspace/bench/prof_gil.txt -- $POOL --out /workspace/bench/pool_prof_gil.json > /workspace/bench/pool_prof_gil.log 2>&1
touch /workspace/bench/DONE7

#!/bin/bash
cd /workspace/Wesnoth-AI
while [ ! -f /workspace/bench/DONE26 ]; do sleep 60; done
export TORCHINDUCTOR_COMPILE_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
WORKERS=14 JOBS=10 bash /workspace/bench/relset_arms_box.sh > /workspace/bench/relset_arms.log 2>&1
touch /workspace/bench/DONE27
